import React, { useCallback } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import SearchListitem from './SearchListitem';
import redHeart from '../../img/redHeart.png';
import borderHeart from '../../img/borderHeart.png';

const SearchList = ({ AllList, updatePrevList, onHeart }) => {
  const useStyles = makeStyles(() => ({
    searchListArea: {
      overflowY: 'auto',
      height: '680px',
      marginTop: '13px',
    },
  }));

  const rowRenderer = useCallback(
    (props) => {
      const searchitem = AllList[props.index];

      return (
        <SearchListitem
          searchitem={searchitem}
          key={props.key}
          updatePrevList={updatePrevList}
          onHeart={onHeart}
          style={props.style}
          AllList={AllList}
        />
      );
    },
    [AllList, updatePrevList, onHeart],
  );

  const classes = useStyles();
  return (
    <div>
      {AllList.map((option, index) => (
        <div key={index}>
          {option.favorite === 'true' ? (
            <img
              src={redHeart}
              alt={''}
              className={classes.HeartImg}
              onClick={() => onHeart(option, option.favorite)}
            />
          ) : (
            <img
              src={borderHeart}
              alt={''}
              className={classes.HeartImg}
              onClick={() => onHeart(option, option.favorite)}
            />
          )}

          <span
            onClick={(e) => {
              updatePrevList(option);
            }}
          >
            {`${option.htmComNm} - ${option.htmAlias} `}
          </span>
        </div>
      ))}
    </div>

    // <List
    //   className={classes.searchListArea}
    //   width={550}
    //   height={680}
    //   rowCount={AllList.length}
    //   rowHeight={45}
    //   rowRenderer={rowRenderer}
    //   list={AllList}
    //   style={{ outline: 'none' }}
    // />
  );
};

export default React.memo(SearchList);
