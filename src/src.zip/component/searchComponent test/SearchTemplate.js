import SearchList from './SearchList';
import SearchAutocomplete from './SearchAutocomplete';
import { makeStyles } from '@material-ui/core/styles';
import React from 'react';

const SearchTemplate = ({ AllList, updatePrevList, onHeart }) => {
  const useStyles = makeStyles(() => ({
    Section: {
      position: 'absolute',
    },
    searchSection: {
      width: '1000px',
      height: '350px',
      top: '90px',
      //border: '1px solid black',
    },
  }));

  const classes = useStyles();
  /*
  //입력한 text랑 이름이 같은 리스트만 보이기
  const search = useCallback(
    (val) => {
      setAllList((AllList) =>
        AllList.filter(
          (item) => item.htmComNm === val || item.htmAlias === val,
        ),
      );
    },
    [setAllList],
  );

  const changeSearch = useCallback(
    (inputText) => {
      if (inputText)
        inputText.htmComNm !== undefined
          ? search(inputText.htmComNm)
          : search(inputText);
      else setAllList((AllList) => ...AllList);
    },
    [search, setAllList],
  );
*/
  return (
    <article className={`${classes.Section} ${classes.searchSection} `}>
      <SearchAutocomplete
        searchList={AllList}
        updatePrevList={updatePrevList}
        onHeart={onHeart}
      />
      {/* {
        <SearchList
          AllList={AllList}
          updatePrevList={updatePrevList}
          onHeart={onHeart}
        />
      } */}
    </article>
  );
};

export default React.memo(SearchTemplate);
