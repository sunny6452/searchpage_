import { ListItemText } from '@material-ui/core';
import React from 'react';
import styled from 'styled-components';
import { makeStyles } from '@material-ui/core/styles';
import redHeart from '../../img/redHeart.png';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';

const StyledTable = styled.table`
  //border: 1px solid black;
  margin-top: 10px;
  td {
    //border: 1px solid black;
    box-shadow: 0px 5px 15px rgb(0 0 0 / 15%);
    width: 200px;
    height: 90px;
  }
`;
const useStyles = makeStyles(() => ({
  delete: {
    marginLeft: '170px',
    width: '1.2rem',
    height: '1rem',
  },
}));
const FavoriteList = ({ favoriteList }) => {
  const classes = useStyles();
  //console.log('favoriteList', favoriteList);
  //const test = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
  const x = Math.ceil(favoriteList.length / 5);
  //console.log(test.slice(0, 5));
  const arr = Array.from({ length: x }, (undefined, i) => i);
  //console.log('arr', arr);
  const tdList = (startNum, endNum) =>
    favoriteList.slice(startNum, endNum).map((favorite, index) => {
      console.log('item', favorite);
      return (
        <td key={index + favorite.htmComcd}>
          <DeleteForeverIcon className={classes.delete} />
          <ListItemText
            //className={classes.searchCPList}
            primary={favorite.htmComNm}
            secondary={`${favorite.htmAlias} / ${favorite.htmComCd} / '시간없음'`}
            onClick={(e) => {
              //updatePrevList(favorite);
            }}
          />
        </td>
      );
    });

  const trList = (rowNum) => {
    let startNum = rowNum * 5;
    let endNum = startNum + 5;
    if (endNum >= favoriteList.length) endNum = favoriteList.length;
    return <tr>{tdList(startNum, endNum)}</tr>;
  };

  const viewTable = (num) => {
    return trList(num);
  };

  return (
    <div>
      <StyledTable>
        <tbody>
          {arr.map((n, index) => {
            return viewTable(n);
          })}
        </tbody>
      </StyledTable>
    </div>
  );
};

export default FavoriteList;
